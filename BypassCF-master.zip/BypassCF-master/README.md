# BYPASS CLOUDFLARE | CIÊNCIA HACKER ~ HackerOrientado


O Bypass CloudFlare é um script em Perl feito para quem quer burlar uma das funções do CloudFlare que é esconder o IP verdadeiro.

# MÓDULOS QUE SERÃO NECESSÁRIOS PARA USAR O SCRIPT

1. WWW::Mechanize
2. utf8
3. Getopt::Long

Todos eles são encontrados no CPAN

-> http://www.cpan.org/

---------------

Créditos total ao site www.crimeflare.com por tornar possível este script funcionar.
Créditos também ao GoogleINURL por ter me ajudado e mostrado um vídeo que me deu esta ideia.
Muito obrigado ao @7mm5l por ter me ajudado muito nas madrugadas com o code.
